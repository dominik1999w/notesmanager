To execute NotesManager use "start.sh".
Open terminal and type:

chmod u+x start.sh

then you will be able to start app with the command:

./start.sh

HAVE FUN! :D
