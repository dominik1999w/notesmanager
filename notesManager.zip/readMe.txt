
-----------------------------------------------------NOTESMANAGER-----------------------------------------------

Instalacja:

0. Preferowana wersja javy 11, może działać na wcześniejszych, ale nie musi.

1. Pobierz javafx 11.0.2 z: 
https://gluonhq.com/products/javafx/ 

2. Otwórz dołączony plik start.sh i podmień: [JAVAFX_PATH] na ścieżkę do folderu z pobraną javafx/lib
czyli na przykład, jeśli umieściłeś/aś pobrany folder w domyślnej lokalizacji javy (zalecane) to prawdobodobnie będzie to:
 /usr/lib/jvm/java-11-openjdk-am64/javafx-sdk-11.0.2/lib/

3. Nadaj odpowiednie uprawnienia wykonywania skryptowi.

4. Odpal skrypt.

5. Jest szansa, że będzie działać bez skryptu, zależy od środowiska i sprzętu.
