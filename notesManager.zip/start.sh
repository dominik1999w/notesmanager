#!/bin/bash
java --module-path [JAVAFX_PATH] --add-modules=javafx.controls,javafx.fxml,javafx.graphics,javafx.base --add-exports=javafx.base/com.sun.javafx.event=ALL-UNNAMED -jar notesmanager.jar
